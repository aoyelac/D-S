function [NBe,NMe,NSe,ZOe,PSe,PMe,PBe,NBec,NMec,NSec,ZOec,PSec,PMec,PBec,NBecc,NMecc,NSecc,ZOecc,PSecc,PMecc,PBecc] = fcn(e,ec,ecc)
coder.extrinsic('integral');
coder.extrinsic('fmincon');
% The purpose is to judge the subordination of velocity state 

   %% These are the method of acquiring sselected seven models confidence degree under the three types of evidence input
    f1=@(e)(1-2*e).*(e<=0.5)+(2*e-1).*(e>0.5&e<=1)+(3-2*e).*(e>1&e<=1.5)+(2*e-3).*(e>1.5);
    f2=@(ec)(2*ec).*(ec<=0.5)+(1).*(ec>0.5&ec<=1.5)+(-2*ec+4).*(ec>1.5);
    f3=@(ecc)(ecc).*(ecc<=1)+(2-ecc).*(ecc>1);
   %% The mode membership of Error e is calculated under f1 condition 
        new_e  =e/(2*pi)+0.5;                                    %Determine the starting point of calculation  e'
        %area_ec =0.5;
        Con_e=[1,7];
        for i = 0:6
            min=new_e+i/7;
            max=new_e+(i+1)/7;
            if min<=0.5 && max>0.5
                Con_e(i+1)=(f1(min)*(0.5-min)+f1(max)*(max-0.5));
            elseif min<=1.5 && max>1.5
                Con_e(i+1)=(f1(min)*(1.5-min)+f1(max)*(max-1.5));
            elseif min<=1 && max>1
                Con_e(i+1)=((1+f1(min))*(1-min)+(1+f1(max))*(max-1));
            else
                Con_e(i+1)=(f1(min)+f1(max))*1/7;
            end
        end
        NBe=Con_e(1); NMe=Con_e(2); NSe=Con_e(3); ZOe=Con_e(4);
        PSe=Con_e(5); PMe=Con_e(6); PBe=Con_e(7);
    %% The mode membership of Differential of error ec is calculated under f2 condition 
        new_ec  =ec/1000+0.5;                                   %Determine the starting point of calculation  e'
        h=f2(new_ec);
        if h==1
            area_ec_1 =1-(1-f2(new_ec+1))*(new_ec+1-1.5)/2;
        else
            area_ec_1 =1-(1-f2(new_ec))*(0.5-new_ec)/2;
        end
        i=0;
        Con_ec=[1,7];
        for i = 0:6
            min=new_ec+i/7;
            max=new_ec+(i+1)/7;
            if min<=0.5 && max>0.5
                Con_ec(i+1)=(((1+f2(min))*(0.5-min))/2+(max-0.5))/area_ec_1;
            elseif min<=1.5 && max>1.5
                Con_ec(i+1)=(((1+f2(max))*(max-1.5))/2+(1.5-min))/area_ec_1;         
            else
                Con_ec(i+1)=((f2(min)+f2(max))/14)/area_ec_1;
            end
        end
    NBec=Con_ec(1); NMec=Con_ec(2); NSec=Con_ec(3); ZOec=Con_ec(4);
    PSec=Con_ec(5); PMec=Con_ec(6); PBec=Con_ec(7);
    %% The mode membership of Double differential of error ecc is calculated under f3 condition 
        new_ecc  =ecc/8000000+0.5;                                     %Determine the starting point of calculation  e'
        area_ecc_1 =(1+f3(new_ecc))*(1-new_ecc)/2+(1+f3(new_ecc+1))*(new_ecc)/2;
        Con_ecc=[1,7];
        for i = 0:6
            min=new_ecc+i/7;
            max=new_ecc+(i+1)/7;
            if min<=1 && max>1
                Con_ecc(i+1)=((1+f3(max))*(max-1)/2+((1+f3(min))*(1-min)/2))/area_ecc_1;
            else
                Con_ecc(i+1)=((f3(min)+f3(max))/14)/area_ecc_1;
            end
        end
        NBecc=Con_ecc(1); NMecc=Con_ecc(2); NSecc=Con_ecc(3); ZOecc=Con_ecc(4);
        PSecc=Con_ecc(5); PMecc=Con_ecc(6); PBecc=Con_ecc(7);

