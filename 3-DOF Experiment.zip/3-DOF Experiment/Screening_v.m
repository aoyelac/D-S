
j_cas_1=1;
for i_cas_1= 2:17268
    if abs(Cas_step_v_1.signals.values(i_cas_1))>abs(Cas_step_v_1.signals.values(i_cas_1+1)) && abs(Cas_step_v_1.signals.values(i_cas_1))>abs(Cas_step_v_1.signals.values(i_cas_1-1))
        M_cas_step_1(j_cas_1)=Cas_step_v_1.signals.values(i_cas_1);
        M_cas_step_1_time(j_cas_1)=Cas_step_v_1.time(i_cas_1);
        j_cas_1=j_cas_1+1;
    end
end

Screening_cas_step_v_1(1)=0;
Screening_cas_step_v_1_time(1)=0;
q_cas_1=2;
for z_cas_1=2:j_cas_1-1
    if M_cas_step_1(z_cas_1) > 70 || M_cas_step_1(z_cas_1) < -70
       Screening_cas_step_v_1(q_cas_1)= M_cas_step_1(z_cas_1);
       Screening_cas_step_v_1_time(q_cas_1)=M_cas_step_1_time(z_cas_1);
       q_cas_1=q_cas_1+1;
    end
end
Screening_cas_step_v_1(q_cas_1)=0;
Screening_cas_step_v_1_time(q_cas_1)=5;


j_cas_2=1;
for i_cas_2= 2:17268
    if abs(Cas_step_v_2.signals.values(i_cas_2))>abs(Cas_step_v_2.signals.values(i_cas_2+1)) && abs(Cas_step_v_2.signals.values(i_cas_2))>abs(Cas_step_v_2.signals.values(i_cas_2-1))
        M_cas_step_2(j_cas_2)=Cas_step_v_2.signals.values(i_cas_2);
        M_cas_step_2_time(j_cas_2)=Cas_step_v_2.time(i_cas_2);
        j_cas_2=j_cas_2+1;
    end
end

Screening_cas_step_v_2(1)=0;
Screening_cas_step_v_2_time(1)=0;
q_cas_2=2;
for z_cas_2=2:j_cas_2-1
    if M_cas_step_2(z_cas_2) > 60 || M_cas_step_2(z_cas_2) < -60
       Screening_cas_step_v_2(q_cas_2)= M_cas_step_2(z_cas_2);
       Screening_cas_step_v_2_time(q_cas_2)=M_cas_step_2_time(z_cas_2);
       q_cas_2=q_cas_2+1;
    end
end
Screening_cas_step_v_2(q_cas_2)=0;
Screening_cas_step_v_2_time(q_cas_2)=5;

j_cas_3=1;
for i_cas_3= 2:17268
    if abs(Cas_step_v_3.signals.values(i_cas_3))>abs(Cas_step_v_3.signals.values(i_cas_3+1)) && abs(Cas_step_v_3.signals.values(i_cas_3))>abs(Cas_step_v_3.signals.values(i_cas_3-1))
        M_cas_step_3(j_cas_3)=Cas_step_v_3.signals.values(i_cas_3);
        M_cas_step_3_time(j_cas_3)=Cas_step_v_3.time(i_cas_3);
        j_cas_3=j_cas_3+1;
    end
end

Screening_cas_step_v_3(1)=0;
Screening_cas_step_v_3_time(1)=0;
q_cas_3=1;
for z_cas_3=2:j_cas_3-1
    if M_cas_step_3(z_cas_3) > 50 || M_cas_step_3(z_cas_3) < -50
       Screening_cas_step_v_3(q_cas_3)= M_cas_step_3(z_cas_3);
       Screening_cas_step_v_3_time(q_cas_3)=M_cas_step_3_time(z_cas_3);
       q_cas_3=q_cas_3+1;
    end
end
Screening_cas_step_v_3(q_cas_3)=0;
Screening_cas_step_v_3_time(q_cas_3)=5;

j_Fu_1=1;
for i_Fu_1= 2:17142
    if abs(Fu_step_v_1.signals.values(i_Fu_1))>abs(Fu_step_v_1.signals.values(i_Fu_1+1)) && abs(Fu_step_v_1.signals.values(i_Fu_1))>abs(Fu_step_v_1.signals.values(i_Fu_1-1))
        M_Fu_step_1(j_Fu_1)=Fu_step_v_1.signals.values(i_Fu_1);
        M_Fu_step_1_time(j_Fu_1)=Fu_step_v_1.time(i_Fu_1);
        j_Fu_1=j_Fu_1+1;
    end
end

Screening_Fu_step_v_1(1)=0;
Screening_Fu_step_v_1_time(1)=0;
q_Fu_1=2;
for z_Fu_1=2:j_Fu_1-1
    if M_Fu_step_1(z_Fu_1) > 50 || M_Fu_step_1(z_Fu_1) < -50
       Screening_Fu_step_v_1(q_Fu_1)= M_Fu_step_1(z_Fu_1);
       Screening_Fu_step_v_1_time(q_Fu_1)=M_Fu_step_1_time(z_Fu_1);
       q_Fu_1=q_Fu_1+1;
    end
end
Screening_Fu_step_v_1(q_Fu_1)=0;
Screening_Fu_step_v_1_time(q_Fu_1)=5;


j_Fu_2=1;
for i_Fu_2= 2:17142
    if abs(Fu_step_v_2.signals.values(i_Fu_2))>abs(Fu_step_v_2.signals.values(i_Fu_2+1)) && abs(Fu_step_v_2.signals.values(i_Fu_2))>abs(Fu_step_v_2.signals.values(i_Fu_2-1))
        M_Fu_step_2(j_Fu_2)=Fu_step_v_2.signals.values(i_Fu_2);
        M_Fu_step_2_time(j_Fu_2)=Fu_step_v_2.time(i_Fu_2);
        j_Fu_2=j_Fu_2+1;
    end
end

Screening_Fu_step_v_2(1)=0;
Screening_Fu_step_v_2_time(1)=0;
q_Fu_2=2;
for z_Fu_2=2:j_Fu_2-1
    if M_Fu_step_2(z_Fu_2) > 45 || M_Fu_step_2(z_Fu_2) < -45
       Screening_Fu_step_v_2(q_Fu_2)= M_Fu_step_2(z_Fu_2);
       Screening_Fu_step_v_2_time(q_Fu_2)=M_Fu_step_2_time(z_Fu_2);
       q_Fu_2=q_Fu_2+1;
    end
end
Screening_Fu_step_v_2(q_Fu_2)=0;
Screening_Fu_step_v_2_time(q_Fu_2)=5;

j_Fu_3=1;
for i_Fu_3= 2:17142
    if abs(Fu_step_v_3.signals.values(i_Fu_3))>abs(Fu_step_v_3.signals.values(i_Fu_3+1)) && abs(Fu_step_v_3.signals.values(i_Fu_3))>abs(Fu_step_v_3.signals.values(i_Fu_3-1))
        M_Fu_step_3(j_Fu_3)=Fu_step_v_3.signals.values(i_Fu_3);
        M_Fu_step_3_time(j_Fu_3)=Fu_step_v_3.time(i_Fu_3);
        j_Fu_3=j_Fu_3+1;
    end
end

Screening_Fu_step_v_3(1)=0;
Screening_Fu_step_v_3_time(1)=0;
q_Fu_3=1;
for z_Fu_3=2:j_Fu_3-1
    if M_Fu_step_3(z_Fu_3) > 40 || M_Fu_step_3(z_Fu_3) < -40
       Screening_Fu_step_v_3(q_Fu_3)= M_Fu_step_3(z_Fu_3);
       Screening_Fu_step_v_3_time(q_Fu_3)=M_Fu_step_3_time(z_Fu_3);
       q_Fu_3=q_Fu_3+1;
    end
end
Screening_Fu_step_v_3(q_Fu_3)=0;
Screening_Fu_step_v_3_time(q_Fu_3)=5;

j_Adfu_1=1;
for i_Adfu_1= 2:9646
    if abs(Adfu_step_v_1.signals.values(i_Adfu_1))>abs(Adfu_step_v_1.signals.values(i_Adfu_1+1)) && abs(Adfu_step_v_1.signals.values(i_Adfu_1))>abs(Adfu_step_v_1.signals.values(i_Adfu_1-1))
        M_Adfu_step_1(j_Adfu_1)=Adfu_step_v_1.signals.values(i_Adfu_1);
        M_Adfu_step_1_time(j_Adfu_1)=Adfu_step_v_1.time(i_Adfu_1);
        j_Adfu_1=j_Adfu_1+1;
    end
end

Screening_Adfu_step_v_1(1)=0;
Screening_Adfu_step_v_1_time(1)=0;
q_Adfu_1=2;
for z_Adfu_1=1:j_Adfu_1-1
    if M_Adfu_step_1(z_Adfu_1) > 45 || M_Adfu_step_1(z_Adfu_1) < -45
       Screening_Adfu_step_v_1(q_Adfu_1)= M_Adfu_step_1(z_Adfu_1);
       Screening_Adfu_step_v_1_time(q_Adfu_1)=M_Adfu_step_1_time(z_Adfu_1);
       q_Adfu_1=q_Adfu_1+1;
    end
end
Screening_Adfu_step_v_1(q_Adfu_1)=0;
Screening_Adfu_step_v_1_time(q_Adfu_1)=5;


j_Adfu_2=1;
for i_Adfu_2= 2:9646
    if abs(Adfu_step_v_2.signals.values(i_Adfu_2))>abs(Adfu_step_v_2.signals.values(i_Adfu_2+1)) && abs(Adfu_step_v_2.signals.values(i_Adfu_2))>abs(Adfu_step_v_2.signals.values(i_Adfu_2-1))
        M_Adfu_step_2(j_Adfu_2)=Adfu_step_v_2.signals.values(i_Adfu_2);
        M_Adfu_step_2_time(j_Adfu_2)=Adfu_step_v_2.time(i_Adfu_2);
        j_Adfu_2=j_Adfu_2+1;
    end
end

Screening_Adfu_step_v_2(1)=0;
Screening_Adfu_step_v_2_time(1)=0;
q_Adfu_2=2;
for z_Adfu_2=2:j_Adfu_2-1
    if M_Adfu_step_2(z_Adfu_2) > 40 || M_Adfu_step_2(z_Adfu_2) < -40
       Screening_Adfu_step_v_2(q_Adfu_2)= M_Adfu_step_2(z_Adfu_2);
       Screening_Adfu_step_v_2_time(q_Adfu_2)=M_Adfu_step_2_time(z_Adfu_2);
       q_Adfu_2=q_Adfu_2+1;
    end
end
Screening_Adfu_step_v_2(q_Adfu_2)=0;
Screening_Adfu_step_v_2_time(q_Adfu_2)=5;

j_Adfu_3=1;
for i_Adfu_3= 2:9646
    if abs(Adfu_step_v_3.signals.values(i_Adfu_3))>abs(Adfu_step_v_3.signals.values(i_Adfu_3+1)) && abs(Adfu_step_v_3.signals.values(i_Adfu_3))>abs(Adfu_step_v_3.signals.values(i_Adfu_3-1))
        M_Adfu_step_3(j_Adfu_3)=Adfu_step_v_3.signals.values(i_Adfu_3);
        M_Adfu_step_3_time(j_Adfu_3)=Adfu_step_v_3.time(i_Adfu_3);
        j_Adfu_3=j_Adfu_3+1;
    end
end

Screening_Adfu_step_v_3(1)=0;
Screening_Adfu_step_v_3_time(1)=0;
q_Adfu_3=1;
for z_Adfu_3=2:j_Adfu_3-1
    if M_Adfu_step_3(z_Adfu_3) > 35 || M_Adfu_step_3(z_Adfu_3) < -35
       Screening_Adfu_step_v_3(q_Adfu_3)= M_Adfu_step_3(z_Adfu_3);
       Screening_Adfu_step_v_3_time(q_Adfu_3)=M_Adfu_step_3_time(z_Adfu_3);
       q_Adfu_3=q_Adfu_3+1;
    end
end
Screening_Adfu_step_v_3(q_Adfu_3)=0;
Screening_Adfu_step_v_3_time(q_Adfu_3)=5;

j_DS_1=1;
for i_DS_1= 2:16949
    if abs(DS_step_v_1.signals.values(i_DS_1))>abs(DS_step_v_1.signals.values(i_DS_1+1)) && abs(DS_step_v_1.signals.values(i_DS_1))>abs(DS_step_v_1.signals.values(i_DS_1-1))
        M_DS_step_1(j_DS_1)=DS_step_v_1.signals.values(i_DS_1);
        M_DS_step_1_time(j_DS_1)=DS_step_v_1.time(i_DS_1);
        j_DS_1=j_DS_1+1;
    end
end

Screening_DS_step_v_1(1)=0;
Screening_DS_step_v_1_time(1)=0;
T_DS_1=2;
B_DS_1=2;
for z_DS_1=1:j_DS_1-1
    if M_DS_step_1(z_DS_1) > 50
       T_Screening_DS_step_v_1(T_DS_1)= M_DS_step_1(z_DS_1);
       T_Screening_DS_step_v_1_time(T_DS_1)=M_DS_step_1_time(z_DS_1);
       T_DS_1=T_DS_1+1;
    end
    if M_DS_step_1(z_DS_1) < -50
       B_Screening_DS_step_v_1(B_DS_1)= M_DS_step_1(z_DS_1);
       B_Screening_DS_step_v_1_time(B_DS_1)=M_DS_step_1_time(z_DS_1);
       B_DS_1=B_DS_1+1;
    end
end
B_Screening_DS_step_v_1(B_DS_1)=0;
B_Screening_DS_step_v_1_time(B_DS_1)=5;
T_Screening_DS_step_v_1(T_DS_1)=0;
T_Screening_DS_step_v_1_time(T_DS_1)=5;


j_DS_2=1;
for i_DS_2= 2:16949
    if abs(DS_step_v_2.signals.values(i_DS_2))>abs(DS_step_v_2.signals.values(i_DS_2+1)) && abs(DS_step_v_2.signals.values(i_DS_2))>abs(DS_step_v_2.signals.values(i_DS_2-1))
        M_DS_step_2(j_DS_2)=DS_step_v_2.signals.values(i_DS_2);
        M_DS_step_2_time(j_DS_2)=DS_step_v_2.time(i_DS_2);
        j_DS_2=j_DS_2+1;
    end
end

Screening_DS_step_v_2(1)=0;
Screening_DS_step_v_2_time(1)=0;
T_DS_2=2;
B_DS_2=2;
for z_DS_2=2:j_DS_2-1
    if M_DS_step_2(z_DS_2) > 45 
       T_Screening_DS_step_v_2(T_DS_2)= M_DS_step_2(z_DS_2);
       T_Screening_DS_step_v_2_time(T_DS_2)=M_DS_step_2_time(z_DS_2);
       T_DS_2=T_DS_2+1;
    end
    if M_DS_step_2(z_DS_2) < -45
       B_Screening_DS_step_v_2(B_DS_2)= M_DS_step_2(z_DS_2);
       B_Screening_DS_step_v_2_time(B_DS_2)=M_DS_step_2_time(z_DS_2);
       B_DS_2=B_DS_2+1;
    end
end
B_Screening_DS_step_v_2(B_DS_2)=0;
B_Screening_DS_step_v_2_time(B_DS_2)=5;
T_Screening_DS_step_v_2(T_DS_2)=0;
T_Screening_DS_step_v_2_time(T_DS_2)=5;

j_DS_3=1;
for i_DS_3= 2:16949
    if abs(DS_step_v_3.signals.values(i_DS_3))>abs(DS_step_v_3.signals.values(i_DS_3+1)) && abs(DS_step_v_3.signals.values(i_DS_3))>abs(DS_step_v_3.signals.values(i_DS_3-1))
        M_DS_step_3(j_DS_3)=DS_step_v_3.signals.values(i_DS_3);
        M_DS_step_3_time(j_DS_3)=DS_step_v_3.time(i_DS_3);
        j_DS_3=j_DS_3+1;
    end
end

Screening_DS_step_v_3(1)=0;
Screening_DS_step_v_3_time(1)=0;
T_DS_3=2;
B_DS_3=2;
for z_DS_3=2:j_DS_3-1
    if M_DS_step_3(z_DS_3) > 40
       T_Screening_DS_step_v_3(T_DS_3)= M_DS_step_3(z_DS_3);
       T_Screening_DS_step_v_3_time(T_DS_3)=M_DS_step_3_time(z_DS_3);
       T_DS_3=T_DS_3+1;
    end
    if M_DS_step_3(z_DS_3) < -40
       B_Screening_DS_step_v_3(B_DS_3)= M_DS_step_3(z_DS_3);
       B_Screening_DS_step_v_3_time(B_DS_3)=M_DS_step_3_time(z_DS_3);
       B_DS_3=B_DS_3+1;
    end
end
B_Screening_DS_step_v_3(B_DS_3)=0;
B_Screening_DS_step_v_3_time(B_DS_3)=5;
T_Screening_DS_step_v_3(T_DS_3)=0;
T_Screening_DS_step_v_3_time(T_DS_3)=5;
